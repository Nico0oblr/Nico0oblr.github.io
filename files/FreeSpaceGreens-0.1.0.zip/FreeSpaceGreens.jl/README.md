# FreeSpaceGreens.jl

Free-space electromagnetic Green tensors and dipole-contracted Green matrices
for Julia. Given dipole positions and moments, the package builds their interaction
matrix or propagates their electric field to a set of observation points.

The package has no non-standard-library dependencies.

## Quick start

Unzip the source archive, enter the `FreeSpaceGreens.jl` directory and start Julia with `julia --project=.`.

```julia
using FreeSpaceGreens

# Each column is one position/dipole.
positions = [0.0 0.25 0.50;
             0.0 0.00 0.10;
             0.0 0.00 0.00]

dipoles = ComplexF64[1  1  1;
                     0  0  0;
                     0  0  0]

# One 3×3 tensor.
G = green_tensor(positions[:, 1] - positions[:, 2]; k=2π)

# 3N×3N block matrix mapping stacked dipoles to stacked vector fields.
Gvector = vector_green_matrix(positions; k=2π, self=:radiative)

# N×N polarization-contracted matrix dᵢ† Gᵢⱼ dⱼ.
Gscalar = scalar_green_matrix(positions, dipoles; k=2π, self=:radiative)

# One decay-rate-normalized coupling in the published hybrid convention.
coupling = hybrid_coupling(
    positions[:, 1] - positions[:, 2], dipoles[:, 1], dipoles[:, 2]; k=2π
)

# The decay-rate-normalized sign and scale used by hybrid CodeBase.G_twolevel.
K = hybrid_coupling_matrix(
    positions,
    dipoles;
    k=2π,
    decay_rates=ones(3),
    self=:zero,
)
```

Positions are always interpreted as columns of a `3×N` matrix. A vector of
length-three vectors is also accepted. Dipoles may be a `3×N` matrix, a vector
of dipole vectors, or one length-three vector shared by every position.

## Coincident points

All constructors accept a `self` keyword:

- `self=:radiative` uses the finite radiative part `im*k^3/(6π*epsilon0)`;
- `self=:zero` removes diagonal/self coupling, as the older hybrid-array matrix
  assembly did;
- `self=:error` rejects coincident points.

The default is `:radiative` for tensor and contracted Green matrices, and
`:zero` for `hybrid_coupling_matrix` to reproduce the legacy published-code
workflow.

## Cross sets

The matrix constructors also accept distinct observation and source sets:

```julia
Gvector = vector_green_matrix(observation_positions, source_positions)

Gscalar = scalar_green_matrix(
    observation_positions,
    source_positions,
    observation_dipoles,
    source_dipoles,
)
```

## Tests

```julia
using Pkg
Pkg.test("FreeSpaceGreens")
```

The tests compare the new tensor numerically against a literal transcription
of the trusted hybrid-cavity formula and verify the legacy scalar normalization.
