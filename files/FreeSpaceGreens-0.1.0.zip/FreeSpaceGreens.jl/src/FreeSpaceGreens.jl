module FreeSpaceGreens

using LinearAlgebra

export green_tensor,
       scalar_green,
       hybrid_coupling,
       vector_green_matrix,
       scalar_green_matrix,
       hybrid_coupling_matrix

const DEFAULT_K = 2π

raw"""
    green_tensor(r; k=2π, epsilon0=1, self=:radiative, atol=0)

Return the 3×3 outgoing free-space electric Green tensor at displacement `r`.
The convention is copied from the validated hybrid-cavity implementation:

```math
G(r) = \frac{e^{ikr}}{4\pi\epsilon_0 r}
\left[\left(k^2-r^{-2}+ikr^{-1}\right)I
+ \left(-k^2+3r^{-2}-3ikr^{-1}\right)\hat r\hat r^T\right].
```

`self` controls coincident points (`norm(r) ≤ atol`):

* `:radiative` returns ``i k^3 I/(6π epsilon0)``;
* `:zero` returns a zero matrix;
* `:error` throws a `DomainError`.
"""
function green_tensor(
    displacement::AbstractVector{<:Real};
    k::Real=DEFAULT_K,
    epsilon0::Real=1,
    self::Symbol=:radiative,
    atol::Real=0,
)
    length(displacement) == 3 || throw(DimensionMismatch("displacement must have length 3"))
    k > 0 || throw(ArgumentError("k must be positive"))
    epsilon0 > 0 || throw(ArgumentError("epsilon0 must be positive"))
    atol >= 0 || throw(ArgumentError("atol must be nonnegative"))
    self in (:radiative, :zero, :error) ||
        throw(ArgumentError("self must be :radiative, :zero, or :error"))

    T = promote_type(Float64, eltype(displacement), typeof(k), typeof(epsilon0), typeof(atol))
    rvec = T.(displacement)
    r = norm(rvec)

    if r <= atol
        return _self_tensor(T, k, epsilon0, self)
    end

    kr = k * r
    rr = (rvec * transpose(rvec)) / r^2
    identity3 = Matrix{T}(I, 3, 3)
    transverse = k^2 - inv(r^2) + im * k / r
    longitudinal = -k^2 + 3 / r^2 - 3im * k / r
    prefactor = cis(kr) / (4π * epsilon0 * r)
    return prefactor .* (transverse .* identity3 .+ longitudinal .* rr)
end

function _self_tensor(::Type{T}, k::Real, epsilon0::Real, self::Symbol) where {T<:Real}
    if self === :radiative
        return Matrix{Complex{T}}(I, 3, 3) .* (im * T(k)^3 / (6π * T(epsilon0)))
    elseif self === :zero
        return zeros(Complex{T}, 3, 3)
    elseif self === :error
        throw(DomainError(0, "the free-space Green tensor is singular at r = 0"))
    else
        throw(ArgumentError("self must be :radiative, :zero, or :error"))
    end
end

raw"""
    scalar_green(r, left_dipole, right_dipole; kwargs...)

Contract the dyadic tensor as `left_dipole' * G(r) * right_dipole`.
The adjoint on the left dipole matches the hybrid-cavity convention and supports
complex (for example circular) polarizations.
"""
function scalar_green(
    displacement::AbstractVector{<:Real},
    left_dipole::AbstractVector{<:Number},
    right_dipole::AbstractVector{<:Number};
    kwargs...,
)
    length(left_dipole) == 3 || throw(DimensionMismatch("left_dipole must have length 3"))
    length(right_dipole) == 3 || throw(DimensionMismatch("right_dipole must have length 3"))
    return dot(left_dipole, green_tensor(displacement; kwargs...) * right_dipole)
end

raw"""
    hybrid_coupling(r, left_dipole, right_dipole;
                    k=2π, gamma_left=1, gamma_right=1,
                    epsilon0=1, self=:radiative, atol=0)

Return one decay-rate-normalized scalar interaction in the convention used by
`G_twolevel` in the hybrid-array code:

```math
K = -\frac{3π\epsilon_0}{k^3}\sqrt{\gamma_l\gamma_r}\,
    \hat d_l^\dagger G(r)\hat d_r.
```

Dipoles are normalized internally. For coincident identical dipoles,
`self=:radiative` gives `-im*sqrt(gamma_left*gamma_right)/2`.
"""
function hybrid_coupling(
    displacement::AbstractVector{<:Real},
    left_dipole::AbstractVector{<:Number},
    right_dipole::AbstractVector{<:Number};
    k::Real=DEFAULT_K,
    gamma_left::Real=1,
    gamma_right::Real=1,
    epsilon0::Real=1,
    self::Symbol=:radiative,
    atol::Real=0,
)
    gamma_left >= 0 || throw(ArgumentError("gamma_left must be nonnegative"))
    gamma_right >= 0 || throw(ArgumentError("gamma_right must be nonnegative"))
    norm(left_dipole) > 0 || throw(ArgumentError("left_dipole must be nonzero"))
    norm(right_dipole) > 0 || throw(ArgumentError("right_dipole must be nonzero"))

    left = left_dipole / norm(left_dipole)
    right = right_dipole / norm(right_dipole)
    contracted = scalar_green(
        displacement, left, right; k, epsilon0, self, atol
    )
    return -(3π * epsilon0 / k^3) * sqrt(gamma_left * gamma_right) * contracted
end

"""
    vector_green_matrix(positions; kwargs...)
    vector_green_matrix(observation_positions, source_positions; kwargs...)

Construct the block Green matrix for a set of points. Positions are columns of
a `3×N` matrix (a vector of length-three vectors is also accepted). Block
`(i,j)` is `green_tensor(rᵢ-rⱼ)`, so the result maps stacked source vectors to
stacked vector fields and has size `3N_observation × 3N_source`.
"""
function vector_green_matrix(positions; kwargs...)
    points = _point_matrix(positions, "positions")
    return _vector_green_matrix(points, points; kwargs...)
end

function vector_green_matrix(observation_positions, source_positions; kwargs...)
    observations = _point_matrix(observation_positions, "observation_positions")
    sources = _point_matrix(source_positions, "source_positions")
    return _vector_green_matrix(observations, sources; kwargs...)
end

function _vector_green_matrix(observations::AbstractMatrix, sources::AbstractMatrix; kwargs...)
    n_observations = size(observations, 2)
    n_sources = size(sources, 2)
    first_block = green_tensor(observations[:, 1] - sources[:, 1]; kwargs...)
    result = Matrix{eltype(first_block)}(undef, 3n_observations, 3n_sources)

    for j in 1:n_sources, i in 1:n_observations
        rows = (3i - 2):(3i)
        columns = (3j - 2):(3j)
        result[rows, columns] .= green_tensor(observations[:, i] - sources[:, j]; kwargs...)
    end
    return result
end

"""
    scalar_green_matrix(positions, dipoles; normalize=false, kwargs...)
    scalar_green_matrix(obs_positions, src_positions, obs_dipoles, src_dipoles;
                        normalize=false, kwargs...)

Construct the polarization-contracted Green matrix. Dipoles are columns of a
`3×N` matrix (or a vector of length-three vectors). Element `(i,j)` is
`dᵢ' * G(rᵢ-rⱼ) * dⱼ`.

Set `normalize=true` to use only dipole orientations. The default preserves
dipole magnitudes.
"""
function scalar_green_matrix(positions, dipoles; normalize::Bool=false, kwargs...)
    points = _point_matrix(positions, "positions")
    moments = _dipole_matrix(dipoles, size(points, 2), "dipoles"; normalize)
    return _scalar_green_matrix(points, points, moments, moments; kwargs...)
end

function scalar_green_matrix(
    observation_positions,
    source_positions,
    observation_dipoles,
    source_dipoles;
    normalize::Bool=false,
    kwargs...,
)
    observations = _point_matrix(observation_positions, "observation_positions")
    sources = _point_matrix(source_positions, "source_positions")
    observation_moments = _dipole_matrix(
        observation_dipoles, size(observations, 2), "observation_dipoles"; normalize
    )
    source_moments = _dipole_matrix(
        source_dipoles, size(sources, 2), "source_dipoles"; normalize
    )
    return _scalar_green_matrix(
        observations, sources, observation_moments, source_moments; kwargs...
    )
end

function _scalar_green_matrix(observations, sources, observation_dipoles, source_dipoles; kwargs...)
    n_observations = size(observations, 2)
    n_sources = size(sources, 2)
    sample = scalar_green(
        observations[:, 1] - sources[:, 1],
        observation_dipoles[:, 1],
        source_dipoles[:, 1];
        kwargs...,
    )
    result = Matrix{typeof(sample)}(undef, n_observations, n_sources)

    for j in 1:n_sources, i in 1:n_observations
        result[i, j] = scalar_green(
            observations[:, i] - sources[:, j],
            observation_dipoles[:, i],
            source_dipoles[:, j];
            kwargs...,
        )
    end
    return result
end

raw"""
    hybrid_coupling_matrix(positions, dipoles;
                           k=2π, decay_rates=ones(N), self=:zero)

Return the decay-rate-normalized scalar interaction used by `G_twolevel` in
the hybrid-array code. Dipoles are normalized internally and

```math
K_{ij} = -\frac{3π\epsilon_0}{k^3}\sqrt{\gamma_i\gamma_j}\,
         \hat d_i^\dagger G(r_i-r_j)\hat d_j.
```

The legacy code discarded singular diagonal entries, hence the default
`self=:zero`. Choosing `self=:radiative` gives the radiative diagonal
`-im*decay_rates[i]/2` for normalized dipoles.
"""
function hybrid_coupling_matrix(
    positions,
    dipoles;
    k::Real=DEFAULT_K,
    epsilon0::Real=1,
    decay_rates=nothing,
    self::Symbol=:zero,
    atol::Real=0,
)
    points = _point_matrix(positions, "positions")
    n = size(points, 2)
    moments = _dipole_matrix(dipoles, n, "dipoles"; normalize=true)
    rates = decay_rates === nothing ? ones(n) : collect(decay_rates)
    length(rates) == n || throw(DimensionMismatch("decay_rates must have length $n"))
    all(rate -> rate >= 0, rates) || throw(ArgumentError("decay_rates must be nonnegative"))

    return [
        hybrid_coupling(
            points[:, i] - points[:, j], moments[:, i], moments[:, j];
            k,
            gamma_left=rates[i],
            gamma_right=rates[j],
            epsilon0,
            self,
            atol,
        )
        for i in 1:n, j in 1:n
    ]
end

function _point_matrix(points::AbstractMatrix{<:Real}, name::AbstractString)
    size(points, 1) == 3 || throw(DimensionMismatch("$name must have size 3×N"))
    size(points, 2) > 0 || throw(ArgumentError("$name must contain at least one point"))
    return points
end

function _point_matrix(points::AbstractVector{<:AbstractVector{<:Real}}, name::AbstractString)
    isempty(points) && throw(ArgumentError("$name must contain at least one point"))
    all(point -> length(point) == 3, points) ||
        throw(DimensionMismatch("every point in $name must have length 3"))
    return hcat(points...)
end

function _dipole_matrix(
    dipoles::AbstractMatrix{<:Number}, n::Integer, name::AbstractString; normalize::Bool
)
    size(dipoles) == (3, n) || throw(DimensionMismatch("$name must have size 3×$n"))
    return normalize ? _normalized_columns(dipoles, name) : dipoles
end

function _dipole_matrix(
    dipoles::AbstractVector{<:Number}, n::Integer, name::AbstractString; normalize::Bool
)
    length(dipoles) == 3 || throw(DimensionMismatch("a shared $name vector must have length 3"))
    matrix = repeat(reshape(dipoles, 3, 1), 1, n)
    return normalize ? _normalized_columns(matrix, name) : matrix
end

function _dipole_matrix(
    dipoles::AbstractVector{<:AbstractVector{<:Number}},
    n::Integer,
    name::AbstractString;
    normalize::Bool,
)
    length(dipoles) == n || throw(DimensionMismatch("$name must contain $n dipoles"))
    all(dipole -> length(dipole) == 3, dipoles) ||
        throw(DimensionMismatch("every dipole in $name must have length 3"))
    matrix = hcat(dipoles...)
    return normalize ? _normalized_columns(matrix, name) : matrix
end

function _normalized_columns(matrix::AbstractMatrix, name::AbstractString)
    norms = [norm(column) for column in eachcol(matrix)]
    all(norm_value -> !iszero(norm_value), norms) ||
        throw(ArgumentError("$name cannot contain a zero vector when normalize=true"))
    return matrix ./ transpose(norms)
end

end # module
