using FreeSpaceGreens
using LinearAlgebra
using Test

function trusted_hybrid_tensor(rvec; k=2π, epsilon0=1)
    r = norm(rvec)
    if r < 1e-14
        return Matrix{ComplexF64}(I, 3, 3) .* (0.5im * k^3 / (3π * epsilon0))
    end
    g0 = exp(im * k * r) / (4π * r)
    return g0 / epsilon0 .* (
        (k^2 - 1 / r^2 + im * k / r) .* Matrix(I, 3, 3) .+
        ((-k^2 + 3 / r^2 - 3im * k / r) / r^2) .* (rvec * transpose(rvec))
    )
end

@testset "single Green tensor" begin
    for r in ([0.2, -0.3, 0.7], [1.1, 0.0, -0.4]), k in (1.7, 2π)
        @test green_tensor(r; k) ≈ trusted_hybrid_tensor(r; k) rtol=2e-14
        @test green_tensor(-r; k) ≈ green_tensor(r; k)
    end

    k = 3.2
    @test green_tensor(zeros(3); k) ≈ im * k^3 / (6π) .* Matrix(I, 3, 3)
    @test iszero(green_tensor(zeros(3); k, self=:zero))
    @test_throws DomainError green_tensor(zeros(3); k, self=:error)
    @test_throws ArgumentError green_tensor([1.0, 0, 0]; self=:invalid)
end

@testset "set constructors" begin
    positions = [0.0 0.3 -0.2; 0.0 0.1 0.8; 0.0 -0.4 0.5]
    dipoles = ComplexF64[1 0 im; 0 1 1; 0 im 0]
    k = 2.4

    vector_matrix = vector_green_matrix(positions; k, self=:zero)
    @test size(vector_matrix) == (9, 9)
    @test vector_matrix[4:6, 7:9] ≈ green_tensor(positions[:, 2] - positions[:, 3]; k)
    @test iszero(vector_matrix[1:3, 1:3])

    scalar_matrix = scalar_green_matrix(positions, dipoles; k, self=:zero)
    @test size(scalar_matrix) == (3, 3)
    @test scalar_matrix[2, 3] ≈ dot(
        dipoles[:, 2], green_tensor(positions[:, 2] - positions[:, 3]; k) * dipoles[:, 3]
    )
    @test scalar_matrix ≈ scalar_green_matrix(
        collect(eachcol(positions)), collect(eachcol(dipoles)); k, self=:zero
    )

    shared_dipole = [0.0, 0.0, 2.0]
    normalized = scalar_green_matrix(positions, shared_dipole; k, self=:zero, normalize=true)
    unit_dipoles = repeat([0.0, 0.0, 1.0], 1, 3)
    @test normalized ≈ scalar_green_matrix(positions, unit_dipoles; k, self=:zero)
end

@testset "hybrid scalar convention" begin
    positions = [0.0 0.4; 0.0 -0.2; 0.0 0.1]
    dipole = [0.0, 0.0, 1.0]
    gamma = [0.7, 1.3]
    k = 1.9
    result = hybrid_coupling_matrix(positions, dipole; k, decay_rates=gamma)

    rvec = positions[:, 1] - positions[:, 2]
    r = norm(rvec)
    kr = k * r
    angle = dot(rvec / r, dipole)
    legacy = 3 / 4 * sqrt(gamma[1] * gamma[2]) * exp(im * kr) * (
        1 / kr^3 - im / kr^2 - 1 / kr +
        angle^2 * (-3 / kr^3 + 3im / kr^2 + 1 / kr)
    )
    @test result[1, 2] ≈ legacy rtol=2e-14
    @test hybrid_coupling(
        rvec, dipole, dipole; k, gamma_left=gamma[1], gamma_right=gamma[2]
    ) ≈ legacy rtol=2e-14
    @test iszero(result[1, 1])

    radiative = hybrid_coupling_matrix(
        positions, dipole; k, decay_rates=gamma, self=:radiative
    )
    @test diag(radiative) ≈ -0.5im .* gamma
    @test hybrid_coupling(zeros(3), dipole, dipole; k, gamma_left=gamma[1], gamma_right=gamma[1]) ≈ -0.5im * gamma[1]
end

@testset "validation" begin
    @test_throws DimensionMismatch vector_green_matrix(zeros(2, 3))
    @test_throws DimensionMismatch scalar_green_matrix(zeros(3, 2), zeros(3, 3))
    @test_throws ArgumentError scalar_green_matrix(
        zeros(3, 1), zeros(3, 1); normalize=true
    )
end
