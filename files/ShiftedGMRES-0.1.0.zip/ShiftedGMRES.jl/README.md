# ShiftedGMRES.jl

Solve a family of linear systems, each with the same matrix and right-hand side and a different scalar shift. Restarted GMRES builds one Arnoldi basis per cycle and reuses it for all shifts. Real and complex systems are supported.

From the package directory, run either example with Julia 1.10 or later:

```sh
julia --project=. examples/sparse_scan.jl
julia --project=. examples/two_dipoles.jl
```

In another Julia environment, install the local checkout with `Pkg.develop(path="/path/to/ShiftedGMRES.jl")`.

```julia
using ShiftedGMRES
result = shifted_gmres(A, b, shifts; restart=40, maxiter=400, rtol=1e-8)
```

Column `j` of `result.X` is the approximation for shift `shifts[j]`. Check `result.converged[j]` before using it. Each status is computed from the true residual norm in `result.residuals[j]`, using the threshold `max(atol, rtol*norm(b))`. An incomplete solve returns its latest approximation. The iteration count covers Arnoldi steps shared by the sweep. Set `seed=j` to choose a reference system explicitly.

The package originates from a Julia solver for coupled-dipole spectra. The shifted restart uses collinear residuals as in [Frommer and Glässner, *Restarted GMRES for Shifted Linear Systems*](https://doi.org/10.1137/S1064827596304563).
