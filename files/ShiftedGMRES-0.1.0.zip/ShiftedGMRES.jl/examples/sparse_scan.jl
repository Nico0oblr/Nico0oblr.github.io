using ShiftedGMRES, SparseArrays, LinearAlgebra

n = 80
A = spdiagm(-1 => fill(-0.3, n-1), 0 => fill(2.0, n), 1 => fill(0.1, n-1))
b = ones(n)
shifts = [-0.25, 0.5, 1.0]
result = shifted_gmres(A, b, shifts; seed=2, restart=8, rtol=1e-9)
@assert all(result.converged)
for (j, shift) in enumerate(shifts)
    reference = (A + shift*I) \ b
    println((; shift, relative_error=norm(result.X[:,j]-reference)/norm(reference)))
end
