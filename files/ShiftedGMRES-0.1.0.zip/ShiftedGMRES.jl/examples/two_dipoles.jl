using ShiftedGMRES, LinearAlgebra

# Two parallel electric dipoles, perpendicular to their separation.
# Distances in wavelengths, detunings and couplings in units of gamma.
kr = 2π * 0.35
g = (3/4) * cis(kr) * (-1/kr - im/kr^2 + 1/kr^3)
A = [im -g; -g im]
drive = [1, cis(kr)]
detunings = collect(-3:0.25:3)
result = shifted_gmres(A, drive, detunings)
@assert all(result.converged)

# Forward scattered intensity, omitting the common radiation prefactor.
forward = [1, cis(-kr)]
intensity(x) = abs2(transpose(forward) * x)
for (j, delta) in enumerate(detunings)
    I_forward = intensity(result.X[:,j])
    reference = intensity((A + delta*I) \ drive)
    @assert isapprox(I_forward, reference; atol=1e-12)
    println((; delta, I_forward))
end
