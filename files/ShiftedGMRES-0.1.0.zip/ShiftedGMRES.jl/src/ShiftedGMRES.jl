module ShiftedGMRES

using LinearAlgebra
export shifted_gmres

# Build one Arnoldi basis for the seed. A scalar shift changes only the
# diagonal of its projected matrix, so every system can reuse V.
function arnoldi(A, shift, residual, m)
    T = eltype(residual)
    V = zeros(T, length(residual), m + 1)
    H = zeros(T, m + 1, m)
    V[:, 1] = residual / norm(residual)
    for j in 1:m
        v = view(V, :, j)
        w = A * v + shift * v
        scale = norm(w)
        for i in 1:j
            u = view(V, :, i)
            H[i, j] = dot(u, w)
            axpy!(-H[i, j], u, w)
        end
        h = norm(w)
        if h <= eps(real(T)) * scale
            return view(V, :, 1:j), H[1:j+1, 1:j], true
        end
        H[j+1, j] = h
        V[:, j+1] = w / h
    end
    return view(V, :, 1:m), H, false
end

"""
    shifted_gmres(A, b, shifts; seed, restart=40, maxiter=length(b), rtol=1e-8, atol=0)

Solve each (A + shifts[j] I)x = b from zero using restarted multishift GMRES.
The seed defaults to the shift nearest zero. A must provide size, eltype,
and multiplication by a vector. X[:,j] corresponds to shifts[j].
residuals are explicitly computed absolute 2-norms; converged[j] tests
residuals[j] <= max(atol, rtol*norm(b)). iterations counts Arnoldi steps.
"""
function shifted_gmres(A, b::AbstractVector, shifts::AbstractVector;
        seed=nothing, restart=40, maxiter=length(b), rtol=1e-8, atol=0)
    n = length(b)
    size(A) == (n, n) || throw(DimensionMismatch("A must be square and match b"))
    isempty(shifts) && throw(ArgumentError("provide at least one shift"))
    restart isa Integer && restart > 0 || throw(ArgumentError("restart must be a positive integer"))
    maxiter isa Integer && maxiter >= 0 || throw(ArgumentError("maxiter must be a nonnegative integer"))
    all(x -> isfinite(x) && x >= 0, (rtol, atol)) || throw(ArgumentError("invalid tolerance"))
    seed = isnothing(seed) ? argmin(abs.(shifts)) : seed
    seed isa Integer && seed in eachindex(shifts) || throw(ArgumentError("invalid seed index"))
    T = float(promote_type(eltype(A), eltype(b), eltype(shifts)))
    rhs = Vector{T}(b)
    X = zeros(T, n, length(shifts))
    residual(j) = rhs - (A * view(X, :, j) + shifts[j] * view(X, :, j))
    target = max(atol, rtol * norm(rhs))
    # After each restart, the shifted residuals are multiples of the seed residual.
    factors = ones(T, length(shifts))
    r = copy(rhs)
    steps = 0
    while steps < maxiter && norm(r) > 0 && maximum(abs, factors)*norm(r) > target
        V, H, breakdown = arnoldi(A, shifts[seed], r, min(restart, maxiter-steps, n))
        m = size(H, 2)
        steps += m
        g = zeros(T, m+1)
        g[1] = norm(r)
        y = breakdown ? pinv(H)*g : H \ g
        X[:, seed] += V*y
        z = g - H*y
        for j in eachindex(shifts)
            j == seed && continue
            Hj = copy(H)
            for k in 1:m
                Hj[k,k] += shifts[j] - shifts[seed]
            end
            if breakdown
                X[:,j] += V * (pinv(Hj) * (factors[j]*g))
            else
                # Last unknown scales the seed residual for the next cycle.
                system = hcat(Hj, z)
                coeff = try
                    system \ (factors[j]*g)
                catch err
                    err isa SingularException || rethrow()
                    pinv(system) * (factors[j]*g)
                end
                X[:,j] += V * view(coeff, 1:m)
                factors[j] = coeff[end]
            end
        end
        breakdown && break
        r = residual(seed)
    end
    residuals = [norm(residual(j)) for j in eachindex(shifts)]
    return (; X, residuals, converged=residuals .<= target, iterations=steps)
end

end
