using ShiftedGMRES, LinearAlgebra, Test

@testset "Complex shifts, nonzero seed and restarts" begin
    n = 28
    A = Tridiagonal(fill(-0.3im,n-1), complex.(2 .+ (1:n)/n), fill(0.25,n-1))
    b = cis.(1:n)
    shifts = [0.6+0.2im, -0.4im, 1+0im]
    r = shifted_gmres(A,b,shifts; seed=1,restart=3,maxiter=100,rtol=1e-10)
    @test all(r.converged)
    @test r.iterations > 3
    for (j,s) in enumerate(shifts)
        @test r.X[:,j] ≈ (A+s*I)\b rtol=1e-9
        @test r.residuals[j] ≈ norm(b-(A*r.X[:,j]+s*r.X[:,j]))
    end
    partial = shifted_gmres(A,b,shifts; restart=6,maxiter=2,rtol=1e-12)
    @test partial.iterations == 2
    @test !all(partial.converged)
end
@testset "Zero drive and invariant subspace" begin
    A = Diagonal([2.,3.])
    z = shifted_gmres(A,zeros(2),[0.,2.])
    @test all(z.converged) && z.iterations == 0
    r = shifted_gmres(A,[1.,0.],[0.,2.,-2.])
    @test r.converged == [true,true,false]
    @test r.X[:,2] ≈ [0.25,0.]
end
