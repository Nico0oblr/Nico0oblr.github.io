using ShiftedGMRES, FreeSpaceGreens, LinearAlgebra

# x-polarized plane wave traveling along z. Positions in wavelengths.
k = 2π
positions = [0.0 0.0; 0.0 0.0; 0.0 0.35]
dipole = [1.0, 0.0, 0.0]
drive = cis.(k .* positions[3, :])
K = hybrid_coupling_matrix(positions, dipole; k, self=:zero)
A = im*I - K  # unit coherence damping, included once on the diagonal
detunings = collect(-3:0.25:3)
result = shifted_gmres(A, drive, detunings)
@assert all(result.converged)

# Each column of the outer product is one emitter's vector dipole moment.
detector = [3.0, 0.0, 4.0]
G_det = vector_green_matrix([detector], positions; k)
field(x) = G_det * vec(dipole * transpose(x))

for (j, delta) in enumerate(detunings)
    x = result.X[:, j]
    E = field(x)
    intensity = sum(abs2, E)
    direct = (A + delta*I) \ drive
    @assert norm((A + delta*I)*x - drive) / norm(drive) < 1e-10
    @assert isapprox(E, field(direct); rtol=1e-10)
    @assert isapprox(intensity, sum(abs2, field(direct)); rtol=1e-10)
    println((; delta, E, intensity))
end
