using ShiftedGMRES, FreeSpaceGreens, SparseArrays, LinearAlgebra

# Open square lattice. x is the fast index in vec and in the Kronecker sums.
function array_sweep(side; detunings=collect(-3:0.075:3))
    spacing = 0.35
    k = 2π
    dipole = [1.0, 0.0, 0.0]
    sites = side^2
    center = cld(side, 2)
    coords = spacing .* ((1:side) .- center)

    # Model: coherent nearest-neighbor exchange and local coherence damping.
    Jx = real(hybrid_coupling([spacing, 0., 0.], dipole, dipole; k))
    Jy = real(hybrid_coupling([0., spacing, 0.], dipole, dipole; k))
    bonds = spdiagm(-1 => ones(side-1), 1 => ones(side-1))
    unit = spdiagm(0 => ones(side))
    A = 0.5im*I - Jx*kron(unit, bonds) - Jy*kron(bonds, unit)
    drive = zeros(sites)
    drive[LinearIndices((side, side))[center, center]] = 1

    # Two detectors at the same distance from the driven site.
    original = [0.6, -0.4, 2.5]
    tilted = norm(original) * [sinpi(1/10), 0.0, cospi(1/10)]
    detectors = (original, tilted)
    to_detectors = Matrix{ComplexF64}(undef, 3*length(detectors), sites)
    for (site, xy) in enumerate(Iterators.product(coords, coords))
        source = [xy[1], xy[2], 0.0]
        for (m, detector) in enumerate(detectors)
            rows = (3*m-2):(3*m)
            to_detectors[rows, site] = green_tensor(detector - source; k) * dipole
        end
    end

    sweep = @timed shifted_gmres(A, drive, detunings; restart=24, rtol=1e-9)
    result = sweep.value
    @assert all(result.converged)
    # Dimensions of E are Cartesian component, detector, detuning.
    E = reshape(to_detectors * result.X, 3, length(detectors), :)
    intensity = dropdims(sum(abs2, E; dims=1); dims=1)
    relative_residual = maximum(result.residuals) / norm(drive)

    for j in (firstindex(detunings), argmin(abs.(detunings)), lastindex(detunings))
        direct = (A + detunings[j]*I) \ drive
        direct_fields = reshape(to_detectors * direct, 3, :)
        @assert isapprox(result.X[:, j], direct; rtol=1e-8)
        for m in eachindex(detectors)
            direct_field = direct_fields[:, m]
            @assert isapprox(E[:, m, j], direct_field; rtol=1e-8)
            @assert isapprox(intensity[m, j], sum(abs2, direct_field); rtol=1e-8)
        end
    end
    return (; sites, nonzeros=nnz(A), detunings, E, intensity,
            relative_residual, iterations=result.iterations, seconds=sweep.time)
end

BLAS.set_num_threads(1)
array_sweep(8; detunings=[-1.0, 0.0, 1.0])  # compile before timing the sweep
spectrum = array_sweep(320)
j = argmin(abs.(spectrum.detunings))
@show spectrum.sites spectrum.nonzeros length(spectrum.detunings) spectrum.iterations
@show spectrum.relative_residual spectrum.seconds spectrum.E[:, :, j] spectrum.intensity[:, j]
